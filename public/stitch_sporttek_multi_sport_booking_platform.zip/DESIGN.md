---
name: Velocity Performance
colors:
  surface: '#fff8f6'
  surface-dim: '#f1d4ca'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ec'
  surface-container: '#ffe9e2'
  surface-container-high: '#ffe2d8'
  surface-container-highest: '#fadcd2'
  on-surface: '#271812'
  on-surface-variant: '#5b4137'
  inverse-surface: '#3e2c26'
  inverse-on-surface: '#ffede7'
  outline: '#8f7065'
  outline-variant: '#e4beb1'
  surface-tint: '#a73a00'
  primary: '#a73a00'
  on-primary: '#ffffff'
  primary-container: '#ff5c00'
  on-primary-container: '#521800'
  inverse-primary: '#ffb59a'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#0061a6'
  on-tertiary: '#ffffff'
  tertiary-container: '#0096fd'
  on-tertiary-container: '#002d51'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#802a00'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d2e4ff'
  tertiary-fixed-dim: '#a0c9ff'
  on-tertiary-fixed: '#001c37'
  on-tertiary-fixed-variant: '#00497f'
  background: '#fff8f6'
  on-background: '#271812'
  surface-variant: '#fadcd2'
typography:
  display-lg:
    fontFamily: Lexend
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Lexend
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Lexend
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base-unit: 4px
  container-max-width: 1280px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The brand identity for Sporttek is rooted in the concept of "Momentum." This design system delivers an athletic, high-performance aesthetic that bridges the gap between professional sports equipment and cutting-edge SaaS utility. The emotional response is one of readiness and efficiency—motivating users to move from digital booking to physical action.

The chosen style is **Corporate / Modern** with a **High-Contrast** edge. It utilizes a rigorous grid and refined surfaces to maintain a professional "Pro-Tier" feel, while injecting aggressive color accents and bold typography to mirror the energy of a stadium or high-end training facility. This approach ensures the platform feels authoritative enough for venue owners yet energetic enough for athletes.

## Colors

The palette is led by **Action Orange**, a high-visibility hue that signifies energy and movement. This primary color is reserved for critical path actions and interactive highlights.

The neutral palette leverages deep "Slate" grays to provide a sophisticated, professional foundation. In Light Mode, the UI uses large expanses of white and soft gray surfaces to maintain clarity. In Dark Mode, the interface shifts to a "Pitch Black" background with slate-gray containers to mimic the lighting of an indoor arena. High-contrast white text is used against dark backgrounds to ensure maximum legibility during high-speed navigation.

## Typography

The typography system uses a dual-font strategy. **Lexend** is employed for headings; its geometric clarity and athletic heritage provide a sense of speed and motivation. Large headings feature heavy weights and tight letter-spacing to command attention.

**Inter** serves as the functional backbone for all body text, data tables, and interface labels. It is chosen for its exceptional readability in dense SaaS layouts, ensuring that booking times, prices, and player lists are consumed without friction. Labels often use a bold weight and uppercase styling to mimic the "player jersey" aesthetic.

## Layout & Spacing

This design system utilizes a **Fixed Grid** model for desktop views, centering content within a 1280px container to maintain focus. On smaller viewports, it transitions to a fluid 12-column grid.

The spacing rhythm is built on a 4px baseline, but defaults to 8px increments (8, 16, 24, 32) to create a sense of breathability and "high-performance" organization. Generous internal padding within cards and containers is used to prevent the interface from feeling cluttered, even when displaying complex scheduling data.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** supplemented by **Ambient Shadows**. Instead of heavy shadows, the system uses subtle, diffused shadows with a slight gray-blue tint (0% 4px 20px rgba(15, 23, 42, 0.08)) to lift interactive cards from the background.

Depth is primarily communicated through color shifts:
- **Level 0 (Background):** Pure white or deepest slate.
- **Level 1 (Card/Container):** Off-white or secondary-gray.
- **Level 2 (Active/Hover):** White with an ambient shadow.

In Dark Mode, elevation is represented by increasing the lightness of the surface color rather than increasing shadow opacity, maintaining a clean, modern SaaS appearance.

## Shapes

The shape language is **Rounded**, striking a balance between approachable and professional. The 8px (0.5rem) base radius provides a modern "app-like" feel without the softness of a consumer-only platform. 

Large containers like facility cards or booking modals use `rounded-xl` (24px) to create distinct visual groupings, while smaller interactive elements like checkboxes use a tighter `rounded-sm` (4px) to maintain a precise, technical look.

## Components

### Buttons
- **Primary:** Action Orange background, white text, bold Lexend font. 8px corner radius. High-impact.
- **Secondary:** Deep slate outline or ghost style. Used for "Cancel" or "View Details."
- **States:** Hover states should involve a 10% darkening of the background color and a slight upward translate (1px) to suggest tactility.

### Cards
- Facilities and time slots are housed in white (light mode) or slate (dark mode) cards. 
- Features a 1px border (#E2E8F0) and subtle ambient shadow.

### Form Inputs
- Clear, high-contrast borders that thicken on focus. 
- Use "Inter" for input text to ensure zero ambiguity in user-entered data.

### Chips & Badges
- Used for "Available," "Booked," or sport types (e.g., "Tennis," "Soccer"). 
- Semi-transparent backgrounds of the semantic color with high-saturation text.

### Specialized Components
- **Availability Timeline:** A horizontal scrolling component for selecting time slots, using the primary Action Orange to highlight the selected window.
- **Scoreboard Stats:** Large, bold display numbers for facility capacity or user activity rankings.